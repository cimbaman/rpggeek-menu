var logoImg = document.getElementById("logo");
logoImg.setAttribute("src", chrome.runtime.getURL("img/icon32.png"));